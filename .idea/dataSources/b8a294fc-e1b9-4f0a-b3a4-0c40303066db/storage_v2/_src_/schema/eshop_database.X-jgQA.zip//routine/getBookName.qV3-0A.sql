create
    definer = root@localhost procedure getBookName(IN bookId int, OUT book_name varchar(200))
begin
    select eshop_database.book.name
    into book_name
    from eshop_database.book
    where eshop_database.book.id = bookId
    limit 1;
end;

